for i in range(int(input())):
 N,A,B,K=map(int,input().split())
 p=int(N/A)+int(N/B)
 if A%B==0 or B%A==0:p-=2*int(N/max(A,B))
 else:p-=2*int(N/(A*B))
 print('Win'if p>=K else 'Lose')
